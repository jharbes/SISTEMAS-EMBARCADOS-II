#include <main.h>
#include <lcd.c>

void main(){
// declara��o de temperatura ambiente (ta), temperatura na caldeira (tc), press�o na caldeira (p)
   float ta;
   float tc;
   float p;
   
   setup_adc_ports(AN0_TO_AN2, VSS_VDD); // Configura AN0, AN1 e AN2 como entradas anal�gicas
   setup_adc(ADC_CLOCK_INTERNAL | ADC_TAD_MUL_20);// Inicia o conersor A/D            

  set_adc_channel(0);                       // Seleciona o canal do conersor A/D para AN0
  lcd_init();
   lcd_putc("\fPartida...\n");
   delay_ms(1000);
// Teste dos LEDS
   output_high(LED_TEMP_BAIXA);
   delay_ms(200);
   output_low(LED_TEMP_BAIXA);    
   output_high(LED_TEMP_NORMAL);
   delay_ms(200);
   output_low(LED_TEMP_NORMAL);    
   output_high(LED_TEMP_ALTA);
   delay_ms(200);
   output_low(LED_TEMP_ALTA);
    
   output_high(LED_PRESSAO_BAIXA);
   delay_ms(200);
   output_low(LED_PRESSAO_BAIXA);   
   output_high(LED_PRESSAO_NORMAL);
   delay_ms(200);
   output_low(LED_PRESSAO_NORMAL);    
   output_high(LED_PRESSAO_ALTA);
   delay_ms(200);
   output_low(LED_PRESSAO_ALTA);    
    

   while(TRUE){
    set_adc_channel(0);                       // Seleciona o canal do conersor A/D para AN0
   Vin_0= read_adc();                        // Leia o valor do canal 0 em bin�riode 10 bits
   set_adc_channel(1);                       // Seleciona o canal do conersor A/D para AN1
   Vin_1= read_adc();                        // Leia o valor do canal 1 em bin�riode 10 bits   
   set_adc_channel(2);                       // Seleciona o canal do conersor A/D para AN2
   Vin_2= read_adc();                        // Leia o valor do canal 2 em bin�rio de 10 bits
   
  // Calcula os valores de V_0, V_1 e V_2 em volts
  V_0=(Vin_0*5)/1024;
  V_1=(Vin_1*5)/1024;   
  V_2=(Vin_2*5)/1024;
  
  // calcula os valores de tc e ta em �C
          
   tc = V_0 * 100;
   ta = V_1 * 100;
   
   // calcula o valor de p em kpa
   p = (V_2 - 0.204) * 53;
  
     fprintf(PORT1,"Luiz Fernando Silva Lemos\n\r"); // exibe o nome dos integrantes do grupo no Terminal 1
                                                         
  // Exibe tc, ta e p no display LCD e no Terminal 2
  
  fprintf(PORT2,"tc=%1.0gC  ta=%1.0gC  p=%1.0gkpa\r\n",tc,ta,p);                                                                                
  printf(lcd_putc,"\ftc=%1.0gC ta=%1.0gC \n",tc,ta);// escreve no LCD formatado    
  printf(lcd_putc,"p=%1.0gkpa",p);    
  
  
  // acionamento dos LEDs e de mensagens no Terminal 3
  //
  if (tc<110){
      fprintf(PORT3,"Temperatura Baixa\r");
      output_high(LED_TEMP_BAIXA);
      output_low(LED_TEMP_NORMAL);
      output_low(LED_TEMP_ALTA);
  } else if (tc>130){
      fprintf(PORT3,"Temperatura Alta\r");
      output_high(LED_TEMP_ALTA);
      output_low(LED_TEMP_NORMAL);
      output_low(LED_TEMP_BAIXA);
   } else {
      fprintf(PORT3,"Temperatura Normal\r");
      output_high(LED_TEMP_NORMAL);
      output_low(LED_TEMP_ALTA);
      output_low(LED_TEMP_BAIXA);
   }
   
   if (p<150){
      fprintf(PORT3,"Pressao Baixa\r");
      output_high(LED_PRESSAO_BAIXA);
      output_low(LED_PRESSAO_NORMAL);
      output_low(LED_PRESSAO_ALTA);
  } else if (p>180){
      fprintf(PORT3,"Pressao Alta\r");
      output_high(LED_PRESSAO_ALTA);
      output_low(LED_PRESSAO_NORMAL);
      output_low(LED_PRESSAO_BAIXA);
   } else {
      fprintf(PORT3,"Pressao Normal\r");
      output_high(LED_PRESSAO_NORMAL);
      output_low(LED_PRESSAO_ALTA);
      output_low(LED_PRESSAO_BAIXA);
   }

  
   }
}
